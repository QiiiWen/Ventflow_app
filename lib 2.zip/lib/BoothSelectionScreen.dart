import 'package:flutter/material.dart';
import 'BuyBoothScreen.dart'; // Import BuyBoothScreen

class BoothSelectionScreen extends StatefulWidget {
  @override
  _BoothSelectionScreenState createState() => _BoothSelectionScreenState();
}

class _BoothSelectionScreenState extends State<BoothSelectionScreen> {
  final List<Map<String, dynamic>> booths = [
    {'id': '515', 'price': 7000, 'size': '15000mm x 3000mm', 'reserved': false},
    {'id': '517', 'price': 5000, 'size': '12000mm x 2500mm', 'reserved': false},
    {'id': '520', 'price': 3000, 'size': '10000mm x 2000mm', 'reserved': true},
    {'id': '525', 'price': 1000, 'size': '8000mm x 1500mm', 'reserved': false},
  ];
  List<Map<String, dynamic>> selectedBooths = [];

  Color getBoothColor(int price) {
    if (price >= 7000) return Colors.red;
    if (price >= 5000) return Colors.orange;
    if (price >= 3000) return Colors.yellow;
    return Colors.green;
  }

  void toggleSelection(Map<String, dynamic> booth) {
    setState(() {
      if (selectedBooths.contains(booth)) {
        selectedBooths.remove(booth);
      } else {
        selectedBooths.add(booth);
      }
    });
  }

  void confirmSelection() {
    if (selectedBooths.isEmpty) return;
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Your Booths Are:'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ...selectedBooths.map((booth) => Text('Booth ${booth['id']} - RM ${booth['price']}')).toList(),
            Text('You have selected ${selectedBooths.length} booth(s)!'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Back'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => BuyBoothScreen(
                    bannerUrl: "https://example.com/banner.jpg",
                    boothIds: selectedBooths.map((booth) => booth.toString()).toList(),
                    boothPrice: selectedBooths.fold(0.0, (sum, boothId) =>
                    sum + double.parse(booths.firstWhere((booth) => booth['id'] == boothId)['price'].toString())),  // Summed price
                    boothTitle: selectedBooths.join(', '),
                    eventId: "your_event_id",
                    organizer: "Event Organizer Name",
                    userId: "current_user_id",
                  ),
                ),
              );


            },
            child: Text('Next Step!'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Select Your Booth')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            Expanded(
              child: GridView.builder(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                ),
                itemCount: booths.length,
                itemBuilder: (context, index) {
                  final booth = booths[index];
                  final isSelected = selectedBooths.contains(booth);
                  return GestureDetector(
                    onTap: booth['reserved'] ? null : () => toggleSelection(booth),
                    child: Container(
                      decoration: BoxDecoration(
                        color: booth['reserved']
                            ? Colors.grey
                            : isSelected
                            ? Colors.blue
                            : getBoothColor(booth['price']),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Center(
                        child: Text(
                          'Booth ${booth['id']}\nRM ${booth['price']}\n(${booth['size']})',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: confirmSelection,
              child: Text('Confirm'),
            ),
          ],
        ),
      ),
    );
  }
}
