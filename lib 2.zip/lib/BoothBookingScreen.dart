import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class BoothBookingScreen extends StatefulWidget {
  final int eventId;
  final String userId;

  const BoothBookingScreen({
    super.key,
    required this.eventId,
    required this.userId,
  });

  @override
  _BoothBookingScreenState createState() => _BoothBookingScreenState();
}

class _BoothBookingScreenState extends State<BoothBookingScreen> {
  List<dynamic> _booths = [];
  bool _isLoading = true;
  bool _hasError = false;
  bool _isBooking = false; // Prevent multiple clicks
  final supabase = Supabase.instance.client;

  @override
  void initState() {
    super.initState();
    _fetchAvailableBooths();
  }

  /// ✅ Fetch available booths for the event
  Future<void> _fetchAvailableBooths() async {
    setState(() {
      _isLoading = true;
      _hasError = false;
    });

    try {
      final response = await supabase
          .from('booths')
          .select('id, booth_number, size, price, description, features, status')
          .eq('event_id', widget.eventId)
          .eq('status', 'available')
          .order('booth_number', ascending: true);

      if (mounted) {
        setState(() {
          _booths = response;
          _isLoading = false;
        });
      }
    } catch (error) {
      print("❌ Error fetching booths: $error");
      setState(() {
        _hasError = true;
        _isLoading = false;
      });
    }
  }

  /// ✅ Show confirmation dialog before booking a booth
  void _showBookingConfirmation(int boothId) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Confirm Booking"),
          content: Text("Are you sure you want to book this booth?"),
          actions: [
            TextButton(
              child: Text("Cancel"),
              onPressed: () => Navigator.pop(context),
            ),
            ElevatedButton(
              child: Text("Confirm"),
              onPressed: () {
                Navigator.pop(context); // Close dialog
                _bookBooth(boothId);
              },
            ),
          ],
        );
      },
    );
  }

  /// ✅ Function to book a booth
  Future<void> _bookBooth(int boothId) async {
    if (_isBooking) return; // Prevent multiple clicks
    setState(() => _isBooking = true);

    try {
      // ✅ Check if user has already booked a booth
      final existingBooking = await supabase
          .from('booth_bookings')
          .select()
          .eq('exhibitor_id', widget.userId)
          .eq('event_id', widget.eventId)
          .maybeSingle();

      if (existingBooking != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("You have already booked a booth.")),
        );
        setState(() => _isBooking = false);
        return;
      }

      // ✅ Step 1: Insert into booth_bookings table
      await supabase.from('booth_bookings').insert({
        'booth_id': boothId,
        'exhibitor_id': widget.userId,
        'event_id': widget.eventId,
        'status': 'booked'
      });

      // ✅ Step 2: Update booth status to "booked"
      await supabase.from('booths').update({'status': 'booked'}).eq('id', boothId);

      print("✅ Booth booked successfully!");

      // ✅ Step 3: Navigate to booking success screen
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => BookingSuccessScreen(),
        ),
      );
    } catch (error) {
      print("❌ Error booking booth: $error");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error booking booth. Try again!")),
      );
    } finally {
      setState(() => _isBooking = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(title: Text("Book a Booth")),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : _hasError
          ? Center(child: Text("❌ Error loading booths"))
          : _booths.isEmpty
          ? Center(child: Text("No available booths for this event."))
          : ListView.builder(
        itemCount: _booths.length,
        itemBuilder: (context, index) {
          final booth = _booths[index];

          return Card(
            color: Colors.white,
            elevation: 2,
            margin: EdgeInsets.symmetric(vertical: 5, horizontal: 10),
            child: ListTile(
              title: Text(
                "Booth ${booth['booth_number']} - ${booth['size'] ?? 'Not specified'}",
                style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
              ),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("💰 RM ${booth['price']?.toString() ?? 'Not available'}"),
                  Text("📌 ${booth['description'] ?? 'No description available'}"),
                  Text("🔹 Features: ${(booth['features'] as List?)?.join(', ') ?? 'No features available'}"),
                ],
              ),
              trailing: ElevatedButton(
                onPressed: () => _showBookingConfirmation(booth['id']),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                child: Text("Book", style: TextStyle(color: Colors.white)),
              ),
            ),
          );
        },
      ),
    );
  }
}

/// ✅ Booking Success Screen
class BookingSuccessScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.check_circle, color: Colors.green, size: 100),
            SizedBox(height: 20),
            Text("Booth Successfully Booked!", style: GoogleFonts.sen(fontSize: 20)),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: Text("Back to Event Details"),
            )
          ],
        ),
      ),
    );
  }
}
