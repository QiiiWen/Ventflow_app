import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'BuyBoothScreen.dart'; // Import BuyBoothScreen

class BookingConfirmationScreen extends StatefulWidget {
  final String eventId;
  final String userId;
  final List<String> selectedBooths;

  const BookingConfirmationScreen({
    Key? key, // ✅ Ensured key is correctly passed
    required this.eventId,
    required this.userId,
    required this.selectedBooths,
  }) : super(key: key); // ✅ Added super.key

  @override
  _BookingConfirmationScreenState createState() => _BookingConfirmationScreenState();
}

class _BookingConfirmationScreenState extends State<BookingConfirmationScreen> {
  final TextEditingController boothTitleController = TextEditingController();
  final TextEditingController companyNameController = TextEditingController();
  final TextEditingController contactNumberController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController productsServicesController = TextEditingController();
  final TextEditingController companyDescriptionController = TextEditingController();
  final TextEditingController numOfStaffController = TextEditingController();
  final TextEditingController extraRequirementsController = TextEditingController();

  final supabase = Supabase.instance.client;

  Future<void> submitBooking() async {
    try {
      // ✅ Retrieve booth details
      final boothResponse = await supabase
          .from('booths')
          .select('price, organizer, banner_url')
          .eq('id', widget.selectedBooths.first)
          .maybeSingle();

      if (boothResponse == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Error: Booth data not found.")),
        );
        return;
      }

      double boothPrice = (boothResponse['price'] as num?)?.toDouble() ?? 0.0;
      String organizer = boothResponse['organizer'] ?? "Unknown Organizer";
      String bannerUrl = boothResponse['banner_url'] ?? "";

      await supabase.from('booth_bookings').insert({
        'event_id': widget.eventId,
        'user_id': widget.userId,
        'booth_ids': widget.selectedBooths.join(','),
        'booth_title': boothTitleController.text,
        'company_name': companyNameController.text,
        'contact_number': contactNumberController.text,
        'email': emailController.text,
        'products_services': productsServicesController.text,
        'company_description': companyDescriptionController.text,
        'num_of_staff': int.tryParse(numOfStaffController.text) ?? 0,
        'extra_requirements': extraRequirementsController.text,
        'status': 'pending',
      }).then((value) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Booking Successful! Redirecting to payment...")),
        );

        // ✅ Navigate to BuyBoothScreen
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => BuyBoothScreen(
              eventId: widget.eventId,
              userId: widget.userId,
              boothIds: widget.selectedBooths,
              boothTitle: boothTitleController.text,
              boothPrice: boothPrice,
              organizer: organizer,
              bannerUrl: bannerUrl,
            ),
          ),
        );
      }).catchError((error) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Error: ${error.toString()}")),
        );
      });
    } catch (error) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: ${error.toString()}")),
      );
    }
  }

  @override
  Widget build(BuildContext context) { // ✅ Make sure build() method is implemented
    return Scaffold(
      appBar: AppBar(title: const Text('Booking Confirmation')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Booth Title:'),
              TextField(controller: boothTitleController),
              const SizedBox(height: 10),
              const Text('Company Name:'),
              TextField(controller: companyNameController),
              const SizedBox(height: 10),
              const Text('Contact Number:'),
              TextField(controller: contactNumberController),
              const SizedBox(height: 10),
              const Text('Email Address:'),
              TextField(controller: emailController),
              const SizedBox(height: 10),
              const Text('Products/Services Offered:'),
              TextField(controller: productsServicesController),
              const SizedBox(height: 10),
              const Text('Company Description:'),
              TextField(controller: companyDescriptionController),
              const SizedBox(height: 10),
              const Text('Number of Staff Attending:'),
              TextField(controller: numOfStaffController, keyboardType: TextInputType.number),
              const SizedBox(height: 10),
              const Text('Extra Requirements: (Optional)'),
              TextField(controller: extraRequirementsController),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: submitBooking,
                child: const Text('Submit'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
