import 'package:flutter/material.dart';

class SponsorScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Sponsor Dashboard")),
      body: Center(child: Text("Welcome, Sponsor!")),
    );
  }
}
