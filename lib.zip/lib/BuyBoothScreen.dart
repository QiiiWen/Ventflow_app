import 'dart:math';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'OrderConfirmationScreen.dart';

class BuyBoothScreen extends StatefulWidget {
  final String eventId;
  final String userId;
  final List<String> boothIds;
  final String boothTitle;
  final double boothPrice;
  final String organizer;
  final String bannerUrl;

  const BuyBoothScreen({
    super.key,
    required this.eventId,
    required this.userId,
    required this.boothIds,
    required this.boothTitle,
    required this.boothPrice,
    required this.organizer,
    required this.bannerUrl,
  });

  @override
  _BuyBoothScreenState createState() => _BuyBoothScreenState();
}

class _BuyBoothScreenState extends State<BuyBoothScreen> {
  bool _isProcessing = false;
  final supabase = Supabase.instance.client;

  double get _serviceFee => widget.boothPrice * 0.06;
  double get _finalAmount => widget.boothPrice + _serviceFee + 1.00;

  /// ✅ **Create Payment Intent**
  Future<String?> _createPaymentIntent() async {
    try {
      final response = await supabase.functions.invoke('create_payment', body: {
        'amount': (_finalAmount * 100).toInt(), // Convert to cents
      });

      print("📢 Supabase Response: ${response.data}");

      if (response.data == null || !response.data.containsKey('clientSecret')) {
        print("❌ Error: Missing 'clientSecret'");
        return null;
      }

      return response.data['clientSecret'];
    } catch (error) {
      print("❌ Error creating payment intent: $error");
      return null;
    }
  }

  /// ✅ **Process Stripe Payment**
  Future<void> _processPayment() async {
    setState(() => _isProcessing = true);

    try {
      String? clientSecret = await _createPaymentIntent();
      if (clientSecret == null) throw Exception("Failed to get payment intent");

      await Stripe.instance.initPaymentSheet(
        paymentSheetParameters: SetupPaymentSheetParameters(
          paymentIntentClientSecret: clientSecret,
          merchantDisplayName: "VentFlow",
        ),
      );

      await Stripe.instance.presentPaymentSheet();
      await _confirmBoothBooking();

    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Payment failed: $e")),
      );
    } finally {
      setState(() => _isProcessing = false);
    }
  }

  /// ✅ **Confirm Booth Booking in Supabase**
  Future<void> _confirmBoothBooking() async {
    try {
      final existingBooking = await supabase
          .from('booth_bookings')
          .select('id')
          .eq('user_id', widget.userId)
          .eq('event_id', widget.eventId)
          .maybeSingle();

      if (existingBooking != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("You have already booked a booth for this event!")),
        );
        return;
      }

      String transactionId = _generateTransactionId();

      await supabase.from('booth_bookings').insert({
        'user_id': widget.userId,
        'event_id': widget.eventId,
        'booth_ids': widget.boothIds.join(','),
        'booth_title': widget.boothTitle,
        'total_price': _finalAmount,
        'status': 'Paid',
        'transaction_id': transactionId,
      });

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => OrderConfirmationScreen(
            userId: widget.userId,
            transactionId: transactionId,
          ),
        ),
      );

    } catch (error) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error confirming booking: $error")),
      );
    }
  }

  String _generateTransactionId() {
    return "TXN${DateTime.now().millisecondsSinceEpoch}";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF040B41),
      appBar: AppBar(
        backgroundColor: const Color(0xFF040B41),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context), // ✅ Added missing onPressed
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              "Confirm Your Booth Purchase",
              style: GoogleFonts.sen(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 20),
            _isProcessing
                ? const CircularProgressIndicator()
                : ElevatedButton(
              onPressed: _processPayment, // ✅ Ensuring this is present
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.purple,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              child: Center(
                child: Text(
                  "PAY",
                  style: GoogleFonts.sen(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
