import 'dart:math';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:intl/intl.dart';
import 'dart:async';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';

class Exhibitor_EventDetailsScreen extends StatefulWidget {
  final int eventId;
  final String userId;

  const Exhibitor_EventDetailsScreen({
    super.key,
    required this.eventId,
    required this.userId,
  });

  @override
  _Exhibitor_EventDetailsScreenState createState() => _Exhibitor_EventDetailsScreenState();
}

class _Exhibitor_EventDetailsScreenState extends State<Exhibitor_EventDetailsScreen> {
  Map<String, dynamic>? _event;
  final ValueNotifier<Duration> _remainingTime = ValueNotifier(Duration());
  Timer? _timer;
  LatLng? _eventLocation;
  double _distanceInKm = 0.0;
  LatLng? _userLocation;

  @override
  void initState() {
    super.initState();
    _fetchEventDetails();
  }

  Future<void> _fetchEventDetails() async {
    final supabase = Supabase.instance.client;

    try {
      final response = await supabase
          .from('events')
          .select()
          .eq('id', widget.eventId)
          .single();

      setState(() {
        String? bannerPath = response['banner']?.trim();
        if (bannerPath?.startsWith("/") ?? false) bannerPath = bannerPath!.substring(1);
        final bannerUrl = bannerPath != null && bannerPath.isNotEmpty
            ? "https://ropvyxordeaxskpwkqdo.supabase.co/storage/v1/object/public/$bannerPath"
            : null;

        _event = {...response, 'banner': bannerUrl};
        _startCountdown();
        _setEventLocation();
      });

      print("✅ Exhibitor Event Details Fetched Successfully:");
      print("🖼 Event Banner URL: ${_event!['banner']}");
    } catch (error) {
      print("❌ Error fetching event details: $error");
    }
  }

  void _setEventLocation() async {
    if (_event == null) return;

    double? lat = _event!['latitude'];
    double? lng = _event!['longitude'];

    if (lat != null && lng != null) {
      setState(() {
        _eventLocation = LatLng(lat, lng);
      });
    } else {
      setState(() {
        _eventLocation = LatLng(3.1390, 101.6869);
      });
    }

    try {
      Position position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high);

      setState(() {
        _userLocation = LatLng(position.latitude, position.longitude);
        _distanceInKm = _calculateDistance(
            position.latitude, position.longitude, lat ?? 3.1390, lng ?? 101.6869);
      });
    } catch (e) {
      print("⚠ Error fetching user location: $e");
    }
  }

  double _calculateDistance(double lat1, double lon1, double lat2, double lon2) {
    const double radius = 6371;
    double dLat = (lat2 - lat1) * (pi / 180.0);
    double dLon = (lon2 - lon1) * (pi / 180.0);
    double a = sin(dLat / 2) * sin(dLat / 2) +
        cos(lat1 * (pi / 180.0)) *
            cos(lat2 * (pi / 180.0)) *
            sin(dLon / 2) *
            sin(dLon / 2);
    double c = 2 * atan2(sqrt(a), sqrt(1 - a));
    return radius * c;
  }

  void _startCountdown() {
    if (_event == null) return;
    DateTime eventDate = DateTime.parse(_event!['date']);
    _remainingTime.value = eventDate.difference(DateTime.now());

    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      final now = DateTime.now();
      if (now.isBefore(eventDate)) {
        _remainingTime.value = eventDate.difference(now);
      } else {
        timer.cancel();
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_event == null) {
      return Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(title: Text("Exhibitor Event Details")),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (_event!['banner'] != null && _event!['banner']!.isNotEmpty)
              Image.network(_event!['banner']!, height: 200, fit: BoxFit.cover),

            SizedBox(height: 16),
            Text(_event!['name'], style: GoogleFonts.sen(fontSize: 22, fontWeight: FontWeight.bold)),

            SizedBox(height: 5),
            Text("Organized by ${_event!['organizer']}", style: GoogleFonts.sen(fontSize: 14, color: Colors.grey[600])),

            SizedBox(height: 10),
            Text("📅 ${DateFormat('EEE, MMM d, yyyy - hh:mm a').format(DateTime.parse(_event!['date']))}",
                style: GoogleFonts.sen(fontSize: 14, color: Colors.grey[700])),

            SizedBox(height: 10),
            Text("📍 ${_event!['location']}", style: GoogleFonts.sen(fontSize: 14, color: Colors.grey[700])),

            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                print("✅ Exhibitor Joined Event!");
                ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text("You have joined this event!"))
                );
              },
              child: Text("Join Event", style: GoogleFonts.sen(fontSize: 16)),
            ),
          ],
        ),
      ),
    );
  }
}
